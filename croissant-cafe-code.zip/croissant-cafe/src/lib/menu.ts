import hero from "@/assets/hero.jpg";
import choco from "@/assets/choco.jpg";
import latte from "@/assets/latte.jpg";
import interior from "@/assets/interior.jpg";

export const images = { hero, choco, latte, interior };

export type Item = { name: string; desc: string; price: number; img: string; tag?: string };

export const menu: Record<string, Item[]> = {
  Croissants: [
    { name: "Classic Butter Croissant", desc: "72-hour laminated dough, French AOP butter, shatteringly crisp.", price: 4.5, img: hero, tag: "Bestseller" },
    { name: "Pain au Chocolat", desc: "Twin batons of 70% dark chocolate, molten when warm.", price: 5.25, img: choco, tag: "Bestseller" },
    { name: "Almond Croissant", desc: "Twice-baked with frangipane and toasted flaked almonds.", price: 5.75, img: hero },
    { name: "Pistachio Crème Brûlée", desc: "Chef's special — Sicilian pistachio cream, caramelised crust.", price: 6.95, img: choco, tag: "Chef's Special" },
  ],
  Coffee: [
    { name: "Cappuccino", desc: "Double ristretto, velvety micro-foam, cocoa dust.", price: 4.25, img: latte, tag: "Bestseller" },
    { name: "Caramel Latte", desc: "House salted-caramel, single-origin espresso, silky milk.", price: 4.95, img: latte },
    { name: "Café Crème", desc: "The Parisian classic — long espresso softened with cream.", price: 3.75, img: latte },
  ],
  "Sandwiches & Desserts": [
    { name: "Croque Monsieur Croissant", desc: "Jambon de Paris, gruyère, béchamel, golden-baked.", price: 9.5, img: hero, tag: "Chef's Special" },
    { name: "Smoked Salmon & Dill", desc: "Crème fraîche, capers and lemon on a butter croissant.", price: 10.5, img: hero },
    { name: "Chocolate Éclair", desc: "Choux pastry, dark chocolate crémeux, glossy glaze.", price: 5.5, img: choco },
  ],
};

export const allItems = Object.values(menu).flat();
