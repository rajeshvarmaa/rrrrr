import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { Menu, X, Instagram, Facebook, Twitter } from "lucide-react";

const links = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/about", label: "Our Story" },
  { to: "/order", label: "Order & Reserve" },
  { to: "/contact", label: "Visit" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
        <Link to="/" className="font-display text-2xl font-semibold tracking-wide text-primary">
          Croissant <span className="italic text-accent">Café</span>
        </Link>
        <nav className="hidden gap-8 text-sm tracking-wide md:flex">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className="text-muted-foreground transition hover:text-primary" activeProps={{ className: "text-primary font-medium" }} activeOptions={{ exact: true }}>
              {l.label}
            </Link>
          ))}
        </nav>
        <Link to="/order" className="hidden rounded-full bg-primary px-5 py-2 text-sm text-primary-foreground transition hover:opacity-90 md:inline-block">Order online</Link>
        <button className="md:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <nav className="flex flex-col gap-4 border-t border-border px-5 py-5 md:hidden">
          {links.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="font-display text-xl">{l.label}</Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-espresso text-primary-foreground">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-3">
        <div>
          <p className="font-display text-3xl">Croissant <span className="italic text-accent">Café</span></p>
          <p className="mt-3 text-sm opacity-70">Baked at dawn. Poured with love. Since 2014.</p>
        </div>
        <div className="text-sm opacity-80">
          <p>12 Rue des Boulangers, Old Town</p>
          <p className="mt-1">+1 (555) 214-7788 · bonjour@croissantcafe.com</p>
          <p className="mt-3">Mon–Fri 7:00–19:00 · Sat–Sun 8:00–20:00</p>
        </div>
        <div className="flex gap-4 md:justify-end">
          {[Instagram, Facebook, Twitter].map((I, i) => (
            <a key={i} href="#" aria-label="social" className="rounded-full border border-primary-foreground/30 p-3 transition hover:bg-accent hover:text-accent-foreground"><I size={18} /></a>
          ))}
        </div>
      </div>
    </footer>
  );
}

export function PageHero({ eyebrow, title, img }: { eyebrow: string; title: ReactNode; img: string }) {
  return (
    <section className="relative h-[45vh] min-h-72 overflow-hidden">
      <img src={img} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-veil" />
      <div className="fade-up relative mx-auto flex h-full max-w-6xl flex-col justify-end px-5 pb-12 text-primary-foreground">
        <p className="text-xs uppercase tracking-[0.3em] text-accent">{eyebrow}</p>
        <h1 className="mt-2 text-5xl md:text-6xl">{title}</h1>
      </div>
    </section>
  );
}
