import type { Item } from "@/lib/menu";

export function ItemCard({ item, onAdd }: { item: Item; onAdd?: () => void }) {
  return (
    <article className="group overflow-hidden rounded-2xl bg-card shadow-warm transition duration-500 hover:-translate-y-1">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img src={item.img} alt={item.name} loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
        {item.tag && <span className="absolute left-3 top-3 rounded-full bg-gold px-3 py-1 text-xs font-medium text-accent-foreground">{item.tag}</span>}
      </div>
      <div className="p-5">
        <div className="flex items-baseline justify-between gap-3">
          <h3 className="text-2xl">{item.name}</h3>
          <span className="font-display text-xl text-accent">${item.price.toFixed(2)}</span>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">{item.desc}</p>
        {onAdd && (
          <button onClick={onAdd} className="mt-4 rounded-full border border-primary px-4 py-1.5 text-sm text-primary transition hover:bg-primary hover:text-primary-foreground">Add to order</button>
        )}
      </div>
    </article>
  );
}
