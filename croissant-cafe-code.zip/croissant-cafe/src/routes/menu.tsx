import { createFileRoute } from "@tanstack/react-router";
import { images, menu } from "@/lib/menu";
import { ItemCard } from "@/components/ItemCard";
import { PageHero } from "@/components/Layout";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Croissant Café" },
      { name: "description", content: "Croissants, coffee, sandwiches and desserts with prices." },
      { property: "og:title", content: "Menu — Croissant Café" },
      { property: "og:description", content: "Croissants, coffee, sandwiches and desserts." },
    ],
  }),
  component: MenuPage,
});

function MenuPage() {
  return (
    <>
      <PageHero eyebrow="La carte" title="Our Menu" img={images.latte} />
      <div className="mx-auto max-w-6xl px-5 py-20">
        {Object.entries(menu).map(([cat, items]) => (
          <section key={cat} className="mb-20">
            <h2 className="border-b border-border pb-3 text-4xl">{cat}</h2>
            <div className="mt-8 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {items.map((i) => <ItemCard key={i.name} item={i} />)}
            </div>
          </section>
        ))}
      </div>
    </>
  );
}
