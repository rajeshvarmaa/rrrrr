import { createFileRoute } from "@tanstack/react-router";
import { images } from "@/lib/menu";
import { PageHero } from "@/components/Layout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story — Croissant Café" },
      { name: "description", content: "How a love for Parisian mornings became Croissant Café." },
      { property: "og:title", content: "Our Story — Croissant Café" },
      { property: "og:description", content: "How a love for Parisian mornings became Croissant Café." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <PageHero eyebrow="Notre histoire" title="Our Story" img={images.interior} />
      <section className="mx-auto grid max-w-6xl gap-12 px-5 py-24 md:grid-cols-2">
        <div className="space-y-5 text-lg leading-relaxed text-muted-foreground">
          <h2 className="text-5xl text-foreground">A little piece of Paris</h2>
          <p>Croissant Café began with one oven, one recipe, and a memory of warm mornings on a Parisian side street.</p>
          <p>Every croissant is laminated by hand over three days with cultured French butter — 81 delicate layers that crackle with each bite.</p>
          <p>We pair them with single-origin coffee roasted locally, served in a room made for lingering: soft light, rattan chairs, and good company.</p>
        </div>
        <div className="grid grid-cols-3 gap-4 self-center text-center">
          {[["72h", "Dough rest"], ["81", "Butter layers"], ["5am", "Ovens on"]].map(([n, l]) => (
            <div key={l} className="rounded-2xl bg-secondary p-6">
              <p className="font-display text-4xl text-accent">{n}</p>
              <p className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{l}</p>
            </div>
          ))}
        </div>
      </section>
    </>
  );
}
