import { createFileRoute } from "@tanstack/react-router";
import { MapPin, Clock, Phone, Instagram } from "lucide-react";
import { images } from "@/lib/menu";
import { PageHero } from "@/components/Layout";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Visit Us — Croissant Café" },
      { name: "description", content: "Location, opening hours and contact details for Croissant Café." },
      { property: "og:title", content: "Visit Croissant Café" },
      { property: "og:description", content: "Location, hours and contact details." },
    ],
  }),
  component: Contact,
});

const info = [
  { I: MapPin, t: "Location", d: "12 Rue des Boulangers, Old Town" },
  { I: Clock, t: "Hours", d: "Mon–Fri 7:00–19:00 · Sat–Sun 8:00–20:00" },
  { I: Phone, t: "Contact", d: "+1 (555) 214-7788 · bonjour@croissantcafe.com" },
  { I: Instagram, t: "Follow", d: "@croissantcafe on Instagram, Facebook & X" },
];

function Contact() {
  return (
    <>
      <PageHero eyebrow="Venez nous voir" title="Visit Us" img={images.interior} />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 md:grid-cols-2">
        <div className="grid gap-5">
          {info.map(({ I, t, d }) => (
            <div key={t} className="flex gap-4 rounded-2xl bg-card p-6 shadow-warm">
              <I className="mt-1 text-accent" />
              <div><h3 className="text-2xl">{t}</h3><p className="text-muted-foreground">{d}</p></div>
            </div>
          ))}
        </div>
        <iframe title="map" className="min-h-96 w-full rounded-2xl border-0 shadow-warm" loading="lazy"
          src="https://www.openstreetmap.org/export/embed.html?bbox=2.33%2C48.85%2C2.36%2C48.865&layer=mapnik" />
      </section>
    </>
  );
}
