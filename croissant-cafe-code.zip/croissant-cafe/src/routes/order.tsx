import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { allItems, images } from "@/lib/menu";
import { ItemCard } from "@/components/ItemCard";
import { PageHero } from "@/components/Layout";

export const Route = createFileRoute("/order")({
  head: () => ({
    meta: [
      { title: "Order Online & Reserve — Croissant Café" },
      { name: "description", content: "Order croissants and coffee for pickup or book a table." },
      { property: "og:title", content: "Order & Reserve — Croissant Café" },
      { property: "og:description", content: "Order croissants and coffee or book a table." },
    ],
  }),
  component: Order,
});

const field = "w-full rounded-xl border border-input bg-card px-4 py-3 outline-none focus:ring-2 focus:ring-ring";

function Order() {
  const [cart, setCart] = useState<Record<string, number>>({});
  const total = Object.entries(cart).reduce((s, [n, q]) => s + (allItems.find((i) => i.name === n)?.price ?? 0) * q, 0);

  const reserve = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    toast.success("Merci! Your table request has been received.");
    e.currentTarget.reset();
  };

  return (
    <>
      <PageHero eyebrow="Commander" title="Order & Reserve" img={images.hero} />
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-20 lg:grid-cols-[1fr_320px]">
        <div className="grid gap-6 sm:grid-cols-2">
          {allItems.map((i) => (
            <ItemCard key={i.name} item={i} onAdd={() => { setCart((c) => ({ ...c, [i.name]: (c[i.name] ?? 0) + 1 })); toast(`${i.name} added`); }} />
          ))}
        </div>
        <aside className="h-fit rounded-2xl bg-card p-6 shadow-warm lg:sticky lg:top-24">
          <h2 className="text-3xl">Your order</h2>
          {Object.keys(cart).length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground">Nothing yet — add something delicious.</p>
          ) : (
            <ul className="mt-4 space-y-2 text-sm">
              {Object.entries(cart).map(([n, q]) => (
                <li key={n} className="flex justify-between"><span>{q} × {n}</span>
                  <button className="text-muted-foreground hover:text-destructive" onClick={() => setCart(({ [n]: _, ...rest }) => rest)}>✕</button></li>
              ))}
            </ul>
          )}
          <div className="mt-6 flex justify-between border-t border-border pt-4 font-display text-2xl"><span>Total</span><span>${total.toFixed(2)}</span></div>
          <button disabled={!total} onClick={() => { toast.success("Order placed! Ready for pickup in 15 minutes."); setCart({}); }}
            className="mt-5 w-full rounded-full bg-primary py-3 text-primary-foreground transition disabled:opacity-40">Place pickup order</button>
        </aside>
      </section>

      <section id="reserve" className="bg-secondary">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-24 md:grid-cols-2">
          <img src={images.interior} alt="Café interior" loading="lazy" className="rounded-3xl shadow-warm" />
          <form onSubmit={reserve} className="space-y-4">
            <h2 className="text-5xl">Reserve a table</h2>
            <input required name="name" placeholder="Your name" className={field} />
            <input required type="tel" name="phone" placeholder="Phone" className={field} />
            <div className="grid grid-cols-3 gap-3">
              <input required type="date" name="date" className={field} />
              <input required type="time" name="time" className={field} />
              <select name="guests" className={field}>{[1, 2, 3, 4, 5, 6, 8].map((g) => <option key={g}>{g} guests</option>)}</select>
            </div>
            <button className="w-full rounded-full bg-gold py-3 font-medium text-accent-foreground">Request booking</button>
          </form>
        </div>
      </section>
    </>
  );
}
