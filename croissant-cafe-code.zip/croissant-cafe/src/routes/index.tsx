import { createFileRoute, Link } from "@tanstack/react-router";
import { Star } from "lucide-react";
import { allItems, images } from "@/lib/menu";
import { ItemCard } from "@/components/ItemCard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Croissant Café — Freshly Baked Croissants & Artisan Coffee" },
      { name: "description", content: "An elegant French bakery café: buttery croissants, cappuccinos, lattes and pastries. Order online or reserve a table." },
      { property: "og:title", content: "Croissant Café — Freshly Baked Croissants & Coffee" },
      { property: "og:description", content: "Buttery croissants and artisan coffee in a cozy French café." },
    ],
  }),
  component: Index,
});

const reviews = [
  { name: "Amélie R.", text: "The most perfect croissant outside Paris. Flaky, buttery, and still warm at 8am." },
  { name: "Daniel K.", text: "Our Sunday breakfast date spot. The pistachio special is unreal." },
  { name: "Priya S.", text: "Cozy corner, great Wi-Fi, beautiful cappuccinos — my favourite study café." },
];

function Index() {
  const best = allItems.filter((i) => i.tag === "Bestseller");
  const special = allItems.filter((i) => i.tag === "Chef's Special");
  return (
    <>
      <section className="relative h-[92vh] min-h-[560px] overflow-hidden">
        <img src={images.hero} alt="Golden croissants and cappuccino" width={1920} height={1088} className="absolute inset-0 h-full w-full scale-105 object-cover" />
        <div className="absolute inset-0 bg-veil" />
        <div className="relative mx-auto flex h-full max-w-6xl flex-col justify-end px-5 pb-20 text-primary-foreground">
          <p className="fade-up text-xs uppercase tracking-[0.35em] text-accent">Boulangerie · Café · Since 2014</p>
          <h1 className="fade-up mt-4 max-w-3xl text-6xl leading-[0.95] md:text-8xl" style={{ animationDelay: ".15s" }}>
            Baked at dawn, <em className="text-accent">savoured</em> all day.
          </h1>
          <p className="fade-up mt-6 max-w-lg text-lg opacity-85" style={{ animationDelay: ".3s" }}>
            Buttery, crisp croissants and artisan coffee in a cozy corner of France.
          </p>
          <div className="fade-up mt-8 flex flex-wrap gap-4" style={{ animationDelay: ".45s" }}>
            <Link to="/order" className="rounded-full bg-gold px-7 py-3 font-medium text-accent-foreground shadow-warm transition hover:scale-105">Order online</Link>
            <Link to="/order" hash="reserve" className="rounded-full border border-primary-foreground/60 px-7 py-3 transition hover:bg-primary-foreground hover:text-primary">Reserve a table</Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24">
        <p className="text-xs uppercase tracking-[0.3em] text-accent">Most loved</p>
        <div className="flex items-end justify-between">
          <h2 className="mt-2 text-5xl">Our Bestsellers</h2>
          <Link to="/menu" className="text-sm text-primary underline-offset-4 hover:underline">Full menu →</Link>
        </div>
        <div className="mt-10 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {best.map((i) => <ItemCard key={i.name} item={i} />)}
        </div>
      </section>

      <section className="bg-secondary">
        <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 py-24 md:grid-cols-2">
          <img src={images.choco} alt="Chocolate croissant cut open" loading="lazy" width={1024} height={1024} className="rounded-3xl shadow-warm" />
          <div>
            <p className="text-xs uppercase tracking-[0.3em] text-accent">Chef's specials</p>
            <h2 className="mt-2 text-5xl">Signatures from our pastry kitchen</h2>
            <div className="mt-8 space-y-6">
              {special.map((i) => (
                <div key={i.name} className="border-b border-border pb-5">
                  <div className="flex justify-between"><h3 className="text-2xl">{i.name}</h3><span className="font-display text-xl text-accent">${i.price.toFixed(2)}</span></div>
                  <p className="mt-1 text-sm text-muted-foreground">{i.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-24 text-center">
        <p className="text-xs uppercase tracking-[0.3em] text-accent">Kind words</p>
        <h2 className="mt-2 text-5xl">From our guests</h2>
        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {reviews.map((r) => (
            <figure key={r.name} className="rounded-2xl bg-card p-8 text-left shadow-warm">
              <div className="flex gap-1 text-accent">{Array.from({ length: 5 }).map((_, i) => <Star key={i} size={16} fill="currentColor" />)}</div>
              <blockquote className="mt-4 font-display text-xl italic leading-snug">"{r.text}"</blockquote>
              <figcaption className="mt-4 text-sm text-muted-foreground">— {r.name}</figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="relative overflow-hidden">
        <img src={images.latte} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-veil" />
        <div className="relative mx-auto max-w-3xl px-5 py-28 text-center text-primary-foreground">
          <h2 className="text-5xl md:text-6xl">Your table is waiting.</h2>
          <p className="mt-4 opacity-85">Breakfast dates, catch-ups, study sessions — there's always a warm seat.</p>
          <Link to="/order" hash="reserve" className="mt-8 inline-block rounded-full bg-gold px-8 py-3 font-medium text-accent-foreground">Book now</Link>
        </div>
      </section>
    </>
  );
}
